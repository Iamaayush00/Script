# HP Bloatware Removal — Intune Win32 Deployment Guide

## Overview

This package removes HP and Poly bloatware during Windows Autopilot provisioning.
It runs as a Win32 app in **System context**, blocks the **Enrollment Status Page (ESP)**
until it completes, and uses the existence of `C:\Logs\HPBloatware.log` as its
detection signal so Intune knows the script has already run on a given device.

---

## Package Contents

| File            | Purpose                                                       |
|-----------------|---------------------------------------------------------------|
| `Install.ps1`   | Entry point — Intune calls this. Launches Remediate.ps1.      |
| `Remediate.ps1` | The full 11-phase bloatware removal script (v5).              |
| `Detect.ps1`    | Detection script — kept for reference / Proactive Remediation.|
| `Uninstall.ps1` | No-op stub required by Intune's Win32 app schema.             |

---

## Step 1 — Package the .intunewin File

Run this from the folder **containing** `HPBloatwareRemoval\` (i.e. one level up):

```
IntuneWinAppUtil.exe -c .\HPBloatwareRemoval -s Install.ps1 -o .\output
```

| Flag | Value              | Meaning                              |
|------|--------------------|--------------------------------------|
| `-c` | `.\HPBloatwareRemoval` | Source folder (all 4 scripts)    |
| `-s` | `Install.ps1`      | Setup file (entry point for Intune)  |
| `-o` | `.\output`         | Output folder for the .intunewin     |

This produces `.\output\Install.intunewin` — that is the file you upload to Intune.

---

## Step 2 — Add the Win32 App in Intune

**Intune portal → Apps → All apps → Add → Windows app (Win32)**

Upload `Install.intunewin` when prompted.

### App Information tab

| Field        | Value                          |
|--------------|--------------------------------|
| Name         | `HP Bloatware Removal`         |
| Description  | `Removes HP and Poly bloatware during Autopilot provisioning` |
| Publisher    | `Your Org Name`                |
| Version      | `5.0`                          |

### Program tab

| Field                    | Value                                                                                          |
|--------------------------|------------------------------------------------------------------------------------------------|
| Install command          | `powershell.exe -ExecutionPolicy Bypass -NonInteractive -WindowStyle Hidden -File Install.ps1` |
| Uninstall command        | `powershell.exe -ExecutionPolicy Bypass -NonInteractive -WindowStyle Hidden -File Uninstall.ps1` |
| Install behavior         | **System**                                                                                     |
| Device restart behavior  | **App install may force a device restart**  *(lets the script's own exit code decide)*        |
| Return codes             | Leave defaults (0 = success, 3010 = success with reboot)                                       |

> **Important:** Install behavior must be **System** — the script needs admin rights
> to remove AppX packages for all users, stop services, and modify HKLM registry keys.

### Requirements tab

| Field            | Value            |
|------------------|------------------|
| OS architecture  | 64-bit           |
| Minimum OS       | Windows 11 21H2  |

### Detection Rules tab

| Setting      | Value                        |
|--------------|------------------------------|
| Rules format | **Manually configure detection rules** |
| Rule type    | **File**                     |
| Path         | `C:\Logs`                    |
| File or folder | `HPBloatware.log`          |
| Detection method | **File or folder exists**  |

> This tells Intune: "if `C:\Logs\HPBloatware.log` exists, the app is installed
> (i.e. the script has already run — don't run it again)."

### Assignments tab

| Field            | Value                                                       |
|------------------|-------------------------------------------------------------|
| Assignment type  | **Required**                                                |
| Assign to        | Your **device group** (e.g. `SG-Autopilot-HP-Laptops`)     |
| Mode             | Device install (not user)                                   |

> Assign to a **device group**, not a user group. User groups don't work correctly
> for apps that need to run before a user signs in during Autopilot.

---

## Step 3 — Configure the ESP to Block on This App

The app must be listed in the ESP profile so it blocks the Device Setup phase
until the script finishes.

**Intune → Devices → Enrollment → Windows → Enrollment Status Page**

Open your existing ESP profile (or create one) and configure:

| Setting | Value |
|---------|-------|
| Show app and profile configuration progress | **Yes** |
| Block device use until all apps and profiles are installed | **Yes** |
| Allow users to reset device if installation error occurs | Your preference |
| **Block device use until these required apps are installed** | Add `HP Bloatware Removal` |

> Only apps explicitly added to the "block" list hold up the ESP.
> Adding it here ensures the device does not reach the desktop until
> the bloatware removal has completed (exit 0) or failed (exit 1).

---

## Step 4 — Verify It's Working

### During Autopilot

On the ESP screen you should see `HP Bloatware Removal` listed under
**Device setup** with a status of *Installing...* while the script runs,
then *Complete* when it finishes.

### After Provisioning

Check the log on any enrolled device:

```
C:\Logs\HPBloatware.log
```

A successful run ends with:

```
[REMEDIATE] ------- Remediation completed -------
```

### In the Intune Portal

**Devices → Monitor → App install status → HP Bloatware Removal**

Devices that have completed successfully will show **Installed**.
Devices where the log file was already present before the script ran
(e.g. from a prior Proactive Remediation run) will show **Installed**
immediately without re-running — this is correct behaviour.

---

## Re-Running on a Device (Troubleshooting)

Because detection is based on the log file existing, Intune will not
re-run the script on a device where the log is present. To force a re-run:

1. Delete `C:\Logs\HPBloatware.log` on the target device.
2. In Intune, sync the device (**Devices → Sync**).
3. Intune will detect the app as "not installed" and re-run `Install.ps1`.

---

## Notes

- **Proactive Remediation co-existence:** `Detect.ps1` and `Remediate.ps1` are
  unchanged from your existing Proactive Remediation scripts. If you keep the
  Proactive Remediation policy active alongside this Win32 app, both will work
  independently — the Win32 app runs once at Autopilot, Proactive Remediation
  catches any apps that re-install later on a schedule.

- **Wolf Security timing:** Phases 1–3 kill processes and disable self-protection
  before attempting removal. The `Start-Sleep -Seconds 5` in Phase 3 is intentional
  — it gives the tamper protection registry changes time to take effect.

- **Exit code 3010:** Several MSI uninstallers return 3010 (success, reboot needed).
  The script treats 3010 as success and logs accordingly. Configure the Intune
  **Return codes** section to also treat 3010 as success (it is by default).
