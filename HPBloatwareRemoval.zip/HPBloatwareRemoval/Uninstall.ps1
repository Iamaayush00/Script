# =============================================================================
# UNINSTALL: HP Bloatware Removal - No-Op Stub
# Purpose : Intune Win32 apps require an uninstall command. This script is
#           a safe no-op — there is nothing to "uninstall" for a run-once
#           cleanup script. Deleting the log file would cause Intune to
#           re-run the install on the next sync, so we intentionally leave
#           C:\Logs\HPBloatware.log in place.
# Exit 0  : Always succeeds
# =============================================================================

Write-Output "HP Bloatware Removal: uninstall is not applicable for this package."
exit 0
