# =============================================================================
# INSTALL: HP Bloatware Removal - Win32 Entry Point
# Purpose : Called by Intune as the Win32 app install command.
#           Spawns Remediate.ps1 as a child process and passes its
#           exit code back to Intune so the deployment status is accurate.
# Exit 0  : Remediation completed successfully (log written to C:\Logs\HPBloatware.log)
# Exit 1  : Remediation failed unexpectedly
# =============================================================================

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RemediateScript = Join-Path $ScriptRoot "Remediate.ps1"

if (-not (Test-Path $RemediateScript)) {
    Write-Output "ERROR: Remediate.ps1 not found at '$RemediateScript'"
    exit 1
}

try {
    $Proc = Start-Process "powershell.exe" `
        -ArgumentList "-ExecutionPolicy Bypass -NonInteractive -WindowStyle Hidden -File `"$RemediateScript`"" `
        -Wait -PassThru -NoNewWindow -ErrorAction Stop

    exit $Proc.ExitCode
}
catch {
    Write-Output "ERROR: Failed to launch Remediate.ps1 - $_"
    exit 1
}
