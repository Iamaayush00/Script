# =============================================================================
# Script 2 - REMEDIATION: Disable Local "Admin" Account
# Purpose : Disable the local "Admin" account after confirming "LocalAdmin"
#           exists as a fallback. This script includes a safety re-check so it
#           will never disable Admin if LocalAdmin has disappeared between the
#           detection and remediation runs.
# Platform: Microsoft Intune (Proactive Remediation - Remediation Script)
# Exit 0  : Remediation succeeded (Admin disabled) or no action needed
# Exit 1  : Remediation aborted/failed (LocalAdmin missing or error)
# Log     : C:\Logs\LocalAdmin.log
# =============================================================================

$LogPath = "C:\Logs\LocalAdmin.log"
$LogDir  = "C:\Logs"

function Write-Log {
    param([string]$Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    if (-not (Test-Path $LogDir)) {
        New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
    }
    Add-Content -Path $LogPath -Value "$Timestamp [REMEDIATE] $Message"
}

Write-Log "------- Remediation run started -------"

try {
    # Safety re-check: confirm current state before making changes
    $AdminUser      = Get-LocalUser -Name "Admin"      -ErrorAction SilentlyContinue
    $LocalAdminUser = Get-LocalUser -Name "LocalAdmin" -ErrorAction SilentlyContinue

    Write-Log "Pre-remediation state - Admin exists: $($null -ne $AdminUser) | LocalAdmin exists: $($null -ne $LocalAdminUser)"

    # Guard: Admin account not found - nothing to do
    if ($null -eq $AdminUser) {
        Write-Log "RESULT: Admin account not found - no action required"
        Write-Output "No action: Admin account does not exist"
        exit 0
    }

    # Guard: LocalAdmin missing - abort to prevent lockout
    if ($null -eq $LocalAdminUser) {
        Write-Log "ABORT: LocalAdmin account not found. Refusing to disable Admin without a confirmed fallback admin account. Manual review required."
        Write-Output "Aborted: LocalAdmin not found - Admin NOT disabled to prevent lockout"
        exit 1
    }

    # Check if Admin is already disabled
    if (-not $AdminUser.Enabled) {
        Write-Log "RESULT: Admin account already disabled - no action required"
        Write-Output "No action: Admin account is already disabled"
        exit 0
    }

    # All checks passed - disable Admin
    Write-Log "Disabling local account 'Admin'..."
    Disable-LocalUser -Name "Admin" -ErrorAction Stop

    # Confirm the change
    $PostCheck = Get-LocalUser -Name "Admin" -ErrorAction SilentlyContinue
    if ($null -ne $PostCheck -and -not $PostCheck.Enabled) {
        Write-Log "RESULT: Remediation successful - 'Admin' account is now disabled"
        Write-Output "Remediation successful: Admin account disabled"
        exit 0
    }
    else {
        Write-Log "ERROR: Disable command ran but Admin account status could not be confirmed"
        Write-Output "Warning: Could not confirm Admin was disabled - check manually"
        exit 1
    }
}
catch {
    Write-Log "ERROR: Remediation failed unexpectedly - $_"
    Write-Output "Remediation failed: $_"
    exit 1
}
