# =============================================================================
# Script 1 - DETECTION: NTP Server Check
# Purpose : Detect if time.windows.com is set as the Windows NTP server
# Platform: Microsoft Intune (Proactive Remediation - Detection Script)
# Exit 0  : Compliant   - time.windows.com is NOT the NTP server
# Exit 1  : Non-Compliant - time.windows.com IS set (remediation will run)
# Log     : C:\Logs\NTPServer.log
# =============================================================================

$LogPath  = "C:\Logs\NTPServer.log"
$LogDir   = "C:\Logs"
$RegPath  = "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters"
$RegName  = "NtpServer"
$TargetBad = "time.windows.com"

function Write-Log {
    param([string]$Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    if (-not (Test-Path $LogDir)) {
        New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
    }
    Add-Content -Path $LogPath -Value "$Timestamp [DETECT] $Message"
}

Write-Log "------- Detection run started -------"

try {
    $NtpServer = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction Stop).$RegName
    Write-Log "Current NTP server value: $NtpServer"

    if ($NtpServer -like "*$TargetBad*") {
        Write-Log "RESULT: Non-Compliant - '$TargetBad' is set as NTP server"
        Write-Output "Non-Compliant: NTP server is set to time.windows.com"
        exit 1
    }
    else {
        Write-Log "RESULT: Compliant - NTP server is not time.windows.com (Current: $NtpServer)"
        Write-Output "Compliant: NTP server is $NtpServer"
        exit 0
    }
}
catch {
    Write-Log "ERROR: Could not read registry key '$RegPath\$RegName' - $_"
    Write-Output "Error: Failed to read NTP server registry value"
    exit 1
}
