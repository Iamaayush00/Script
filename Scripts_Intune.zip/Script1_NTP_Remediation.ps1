# =============================================================================
# Script 1 - REMEDIATION: NTP Server Fix
# Purpose : Set Windows NTP server to ldbtime.bcliquor.com,
#           restart the Windows Time service, and force an immediate sync
# Platform: Microsoft Intune (Proactive Remediation - Remediation Script)
# Exit 0  : Remediation succeeded
# Exit 1  : Remediation failed
# Log     : C:\Logs\NTPServer.log
# =============================================================================

$LogPath   = "C:\Logs\NTPServer.log"
$LogDir    = "C:\Logs"
$TargetNTP = "ldbtime.bcliquor.com"

function Write-Log {
    param([string]$Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    if (-not (Test-Path $LogDir)) {
        New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
    }
    Add-Content -Path $LogPath -Value "$Timestamp [REMEDIATE] $Message"
}

Write-Log "------- Remediation run started -------"
Write-Log "Target NTP server: $TargetNTP"

try {
    # Step 1: Configure W32tm with the new NTP server
    Write-Log "Step 1: Configuring W32tm..."
    $configResult = & w32tm /config /manualpeerlist:"$TargetNTP" /syncfromflags:manual /reliable:YES /update 2>&1
    Write-Log "W32tm config output: $configResult"

    # Step 2: Restart the Windows Time service to apply the new config
    Write-Log "Step 2: Restarting Windows Time service..."
    Restart-Service -Name "W32Time" -Force -ErrorAction Stop
    Write-Log "Windows Time service restarted successfully"

    # Step 3: Allow the service a moment to fully start before syncing
    Start-Sleep -Seconds 3

    # Step 4: Force an immediate time resync against the new server
    Write-Log "Step 3: Forcing NTP resync..."
    $syncResult = & w32tm /resync /force 2>&1
    Write-Log "W32tm resync output: $syncResult"

    # Step 5: Confirm the new NTP server is set in the registry
    $ConfirmNTP = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters" -Name "NtpServer" -ErrorAction Stop).NtpServer
    Write-Log "Confirmed NTP server in registry: $ConfirmNTP"

    Write-Log "RESULT: Remediation completed successfully"
    Write-Output "Remediation successful: NTP server set to $TargetNTP"
    exit 0
}
catch {
    Write-Log "ERROR: Remediation failed - $_"
    Write-Output "Remediation failed: $_"
    exit 1
}
