# =============================================================================
# Script 2 - DETECTION: Local Admin Account Check
# Purpose : Detect if BOTH local accounts "Admin" and "LocalAdmin" exist.
#           Remediation (disabling Admin) is only triggered when BOTH exist,
#           ensuring LocalAdmin is in place as a fallback before Admin is disabled.
#           If only Admin exists (LocalAdmin not yet created), detection returns
#           Compliant so no action is taken. Intune will re-check on schedule
#           and trigger remediation once LocalAdmin is confirmed present.
# Platform: Microsoft Intune (Proactive Remediation - Detection Script)
# Exit 0  : Compliant   - Safe to leave as-is (either Admin is gone, or
#                         Admin exists but LocalAdmin not yet ready)
# Exit 1  : Non-Compliant - Both Admin AND LocalAdmin exist; disable Admin
# Log     : C:\Logs\LocalAdmin.log
# =============================================================================

$LogPath = "C:\Logs\LocalAdmin.log"
$LogDir  = "C:\Logs"

function Write-Log {
    param([string]$Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    if (-not (Test-Path $LogDir)) {
        New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
    }
    Add-Content -Path $LogPath -Value "$Timestamp [DETECT] $Message"
}

Write-Log "------- Detection run started -------"

try {
    $AdminUser      = Get-LocalUser -Name "Admin"      -ErrorAction SilentlyContinue
    $LocalAdminUser = Get-LocalUser -Name "LocalAdmin" -ErrorAction SilentlyContinue

    $AdminExists      = $null -ne $AdminUser
    $LocalAdminExists = $null -ne $LocalAdminUser

    Write-Log "Account 'Admin' exists      : $AdminExists"
    Write-Log "Account 'LocalAdmin' exists : $LocalAdminExists"

    if ($AdminExists -and $LocalAdminExists) {
        # Both accounts present - safe to disable Admin
        Write-Log "RESULT: Non-Compliant - Both 'Admin' and 'LocalAdmin' exist. Admin will be disabled."
        Write-Output "Non-Compliant: Both Admin and LocalAdmin exist - remediation will disable Admin"
        exit 1
    }
    elseif ($AdminExists -and -not $LocalAdminExists) {
        # Admin exists but LocalAdmin is not yet set up - hold off, check again next cycle
        Write-Log "RESULT: Compliant (deferred) - 'Admin' exists but 'LocalAdmin' not found. Waiting for LocalAdmin to be created before taking action."
        Write-Output "Compliant (deferred): Admin exists but LocalAdmin not found - no action this cycle"
        exit 0
    }
    else {
        # Admin does not exist - nothing to do
        Write-Log "RESULT: Compliant - 'Admin' account does not exist. No action required."
        Write-Output "Compliant: Admin account not present"
        exit 0
    }
}
catch {
    Write-Log "ERROR: Unexpected failure during detection - $_"
    Write-Output "Error: Detection script failed - $_"
    exit 1
}
